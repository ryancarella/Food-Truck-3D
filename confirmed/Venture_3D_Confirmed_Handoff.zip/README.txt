VENTURE 3D STUDIO — CONFIRMED HANDOFF
Project: Carellas Kitchen
Confirmed: 2026-11-03T19:57:42.819Z
Schema: 1.0

Mission 3: Extract this ZIP. Carry model.glb and model-manifest.json into your website project. Load model.glb with Three.js GLTFLoader. All model textures are embedded. Use the manifest camera, lighting, background, dimensions, and SHA-256 checksum. +Y is up; units are meters.

project.json is the editable backup: use Open project / GLB in Venture 3D Studio. preview.png is a screenshot, not the model. Keep the ZIP as a versioned backup. Confirmation does not publish or modify a website.

The truck is an approximate procedural interpretation of the concept reference; it is not a measured reconstruction or a print-ready CAD model.
